//#include "CylinderOptimizedFeatureCalculator.h"

namespace hpe
{

}