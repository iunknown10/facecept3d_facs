#pragma once

#ifndef IINTERFACE_H
#define IINTERFACE_H

namespace hpe
{
    class IInterface
    {
        public:
            virtual ~IInterface() {}
    };
}

#endif // IINTERFACE_H
